package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private Button[][] buttons = new Button[3][3]; // matrix of buttons
    TextView tvWinner,tvTurns;
    String player1, player2;
    int turns;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        player1 = "player1";// X
        player2 = "player2";// O
        tvWinner = findViewById(R.id.tvWinner);
        tvTurns = findViewById(R.id.tvTurns);
        buttons[0][0] = findViewById(R.id.bt1);
        buttons[0][1]  = findViewById(R.id.bt2);
        buttons[0][2]  = findViewById(R.id.bt3);
        buttons[1][0]  = findViewById(R.id.bt4);
        buttons[1][1]  = findViewById(R.id.bt5);
        buttons[1][2]  = findViewById(R.id.bt6);
        buttons[2][0]  = findViewById(R.id.bt7);
        buttons[2][1]  = findViewById(R.id.bt8);
        buttons[2][2]  = findViewById(R.id.bt9);

        buttons[0][0].setOnClickListener(this);
        buttons[0][1].setOnClickListener(this);
        buttons[0][2].setOnClickListener(this);
        buttons[1][0].setOnClickListener(this);
        buttons[1][1].setOnClickListener(this);
        buttons[1][2].setOnClickListener(this);
        buttons[2][0].setOnClickListener(this);
        buttons[2][1].setOnClickListener(this);
        buttons[2][2].setOnClickListener(this);
        turns = 0;
        tvTurns.setText("Turns: " + Integer.toString(turns));

    }
    private boolean winner(String str)// check if player won in his click on button
    {
        boolean check = false;
        for(int k = 0;k < 3 ;k++)//rows
        {
            check = true;
            for(int i = 0;i < 3;i++)
            {
                if(buttons[k][i].getText() != str)
                    check = false;
            }
            if(check)
                return true;
        }
        for(int i = 0;i < 3 ;i++)//cols
        {
            check = true;
            for(int k = 0;k < 3;k++)
            {
                if(buttons[k][i].getText() != str)
                    check = false;
            }
            if(check)
                return true;
        }
        check = true;
        for(int i = 0;i < 3;i++)// diangele 1
        {
            if(buttons[i][i].getText() != str)
                check = false;
        }
        if(check)
            return true;
        check = true;
        for(int i = 0;i < 3;i++)// diangele 2
        {
            if(buttons[i][2-i].getText() != str)
                check = false;
        }
        if(check)
            return true;
        return check;
    }

    @Override
    public void onClick(View view) {
        turns++;
        tvTurns.setText("Turns: " + Integer.toString(turns));
        if(turns == 9)
        {
            tvWinner.setText("Tie");
        }
        else {
            for (int i = 0; i < 3; i++) {
                for (int k = 0; k < 3; k++) {
                    if (view == buttons[i][k]) {
                        if (turns % 2 == 0) {
                            buttons[i][k].setText("O");
                            if(winner("O"))
                                tvWinner.setText("congratulation " + player2 + " Won");
                        }
                        else {
                            buttons[i][k].setText("X");
                            if(winner("X"))
                                tvWinner.setText("congratulation " + player1 + " Won");
                        }
                    }
                }
            }

        }
    }

}